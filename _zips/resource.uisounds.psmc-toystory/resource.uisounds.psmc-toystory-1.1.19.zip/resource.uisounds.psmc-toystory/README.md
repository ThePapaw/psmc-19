GUI Sounds for the PSMC's Toy Story skin.
